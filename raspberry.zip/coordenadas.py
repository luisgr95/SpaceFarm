def planta1():
	planta1= "G01 X10 Y10 Z10"

def planta2():
	planta2="G01 X20 Y20 Z10"

def planta3():
	planta3="G01 X30 Y30 Z10"

def planta4():
	planta4="G01 X40 Y40 Z10"

def planta5():
	planta5="G01 X50 Y50 Z10"

def planta6():
	planta6="G01 X60 Y60 Z10"

def origen():
	planta6="G01 X0 Y0 Z10"

